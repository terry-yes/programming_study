import React, {Component} from 'react';

class Content extends Component {
  render() {
    return (
      <>
        <div>Hello, World!</div>
      </>
    );
  }
}

export default Content;